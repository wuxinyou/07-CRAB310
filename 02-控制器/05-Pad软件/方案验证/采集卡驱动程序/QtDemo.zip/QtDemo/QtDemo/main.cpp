#include "qtdemo.h"
#include <QtWidgets/QApplication>
//#include "DXMediaCap.h"
//#include "datastru.h"

#ifdef UNICODE

#define QStringToTCHAR(x)     (wchar_t*) x.utf16()

#define PQStringToTCHAR(x)    (wchar_t*) x->utf16()

#define TCHARToQString(x)     QString::fromUtf16((x))

#define TCHARToQStringN(x,y)  QString::fromUtf16((x),(y))

#else

#define QStringToTCHAR(x)     x.local8Bit().constData()

#define PQStringToTCHAR(x)    x->local8Bit().constData()

#define TCHARToQString(x)     QString::fromLocal8Bit((x))

#define TCHARToQStringN(x,y)  QString::fromLocal8Bit((x),(y))

#endif
int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	QtDemo w;
	w.show();
	return a.exec();
}
