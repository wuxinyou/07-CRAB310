/********************************************************************************
** Form generated from reading UI file 'qtdemo.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QTDEMO_H
#define UI_QTDEMO_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_QtDemoClass
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QToolButton *SnapButton;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *QtDemoClass)
    {
        if (QtDemoClass->objectName().isEmpty())
            QtDemoClass->setObjectName(QStringLiteral("QtDemoClass"));
        QtDemoClass->resize(680, 544);
        QtDemoClass->setFocusPolicy(Qt::StrongFocus);
        QtDemoClass->setAnimated(false);
        centralWidget = new QWidget(QtDemoClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        SnapButton = new QToolButton(centralWidget);
        SnapButton->setObjectName(QStringLiteral("SnapButton"));
        SnapButton->setEnabled(true);
        QSizePolicy sizePolicy(QSizePolicy::Maximum, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(SnapButton->sizePolicy().hasHeightForWidth());
        SnapButton->setSizePolicy(sizePolicy);
        SnapButton->setFocusPolicy(Qt::StrongFocus);
        SnapButton->setLayoutDirection(Qt::LeftToRight);
        SnapButton->setIconSize(QSize(26, 26));
        SnapButton->setCheckable(false);
        SnapButton->setChecked(false);
        SnapButton->setAutoRaise(false);
        SnapButton->setArrowType(Qt::NoArrow);

        gridLayout->addWidget(SnapButton, 0, 0, 1, 1, Qt::AlignRight|Qt::AlignBottom);

        QtDemoClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(QtDemoClass);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 680, 23));
        QtDemoClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(QtDemoClass);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        QtDemoClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(QtDemoClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        QtDemoClass->setStatusBar(statusBar);

        retranslateUi(QtDemoClass);

        QMetaObject::connectSlotsByName(QtDemoClass);
    } // setupUi

    void retranslateUi(QMainWindow *QtDemoClass)
    {
        QtDemoClass->setWindowTitle(QApplication::translate("QtDemoClass", "QtDemo", 0));
        SnapButton->setText(QApplication::translate("QtDemoClass", "Snap", 0));
    } // retranslateUi

};

namespace Ui {
    class QtDemoClass: public Ui_QtDemoClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QTDEMO_H
