/*==========================================================================*/
/*     (Copyright (C) 2011	 ZhongAn Vision				.               */
/*     All rights reserved.                                                 */
/*																			*/
/*	   Abstract:															*/
/*																			*/
/*     Create 05/2011														*/
/*==========================================================================*/


#ifndef HNLIVEMEDIA_H
// Description:
// This define avoids multiple including of the header content.
#define HNLIVEMEDIA_H

#include "HnLiveType.h"

#ifndef HANAPI
#define HANAPI extern "C" __declspec(dllexport) 
#endif

//////////////////////////////////////////////////////////////////////////

HANAPI int __stdcall HNInitMediaDll();

HANAPI int __stdcall HNUnInitMediaDll();

HANAPI int __stdcall HNGetSdkVersion(long* plHiVersion,long* plLoVersion);

HANAPI int __stdcall HNGetChannNum( int* pnChannNum);

HANAPI int __stdcall HNSetDispParam( int nChann,
									 HWND hDispWnd,
									 long lxPosition,
									 long lyPosition,
									 long lDispWidth,
									 long lDispHeight);

HANAPI int __stdcall HNRegMsgWnd( int nChann,
								  HWND hMsgWnd);

HANAPI int __stdcall HNRegNotifyWnd(int nChann,
									HWND hNotifyWnd);

HANAPI int __stdcall HNGetPropProcamp( int nChann,
									   VideoProCamp_t enVidProCamp,
									   int* pnMaxValue,
									   int* pnMinValue,
									   int* pnDefValue);

HANAPI int __stdcall HNSetPropProcamp( int nChann,
									   VideoProCamp_t enVidProCamp,
									   int nPropValue);

HANAPI int __stdcall HNGetUsePropProcamp( int nChann,
										  VideoProCamp_t enVidProCamp,
										  int* pnPropValue);

HANAPI int __stdcall HNGetVideoSize(  int nChann,
									  int* pnVidWidth,
									  int* pnVidHeight);

HANAPI int __stdcall HNSetVideoSize(  int nChann,
									  int nVidWidth,
									  int nVidHeight);

HANAPI int __stdcall HNGetVideoFmt(  int nChann,
										pVideoOutputFormat_t penVidOutputFmt);

HANAPI int __stdcall HNSetVideoFmt( int nChann,
									  VideoOutputFormat_t enVidOutputFmt);

HANAPI int __stdcall HNGetVideoSource(  int nChann,
										pVideoSource_t penVidSource);

HANAPI int __stdcall HNSetVideoSource(  int nChann,
										VideoSource_t enVidSource);

HANAPI int __stdcall HNGetVideoStandard(  int nChann, 
										  pVideoStandard_t penVidStandard);

HANAPI int __stdcall HNSetVideoStandard(  int nChann,
										  VideoStandard_t enVidStandard);

HANAPI int __stdcall HNGetVideoFieldFreq(  int nChann,
										   int* pnVidFieldFreq);

HANAPI int __stdcall HNSetVideoFieldFreq(  int nChann,
										   int nVidFieldFreq);

HANAPI int __stdcall HNSetVideoCapMode(int nChann,
									   StreamFlagsVideo_t enStreamFlag);

// nValue = 0: stop noise reduce
HANAPI int __stdcall HNSetVidNoiseReduction(int nChann,int nValue /* 0~ 200*/);

//////////////////////////////////////////////////////////////////////////
HANAPI int __stdcall HNGetSnapOrgArea(int nChann,
									  RECT& rc);

HANAPI int __stdcall HNSetSnapOrgArea(int nChann,
									  int nLeft,
									  int nTop,
									  int nWidth,
									  int nHeight);

HANAPI int __stdcall HNGetSnapBuffer(int nChann,
									 BYTE* pucBuffer,
									 long*  plVidWidth,
									 long*  plVidHeight,
									 long* plBuffSize,
									 pVideoOutputFormat_t pVidFmt);

//The Buffer format is RGB24-format
HANAPI int __stdcall HNSaveBufftoBmp( int nChann,
									  BYTE* pucBuffer,
									  long lBuffSize,
									  long lImgWidth,
									  long lImgHeight,
									  char* szImagPath);

//The Buffer format is RGB24-format
HANAPI int __stdcall HNSaveBufftoJpg( int nChann,
									  BYTE* pucBuffer,
									  long lBuffSize,
									  long lImgWidth,
									  long lImgHeight,
									  char* szImagPath,
									  long lImgQuality /*1~100*/);

HANAPI int __stdcall HNSnaptoBmp(int nChann,
								 char* szBmpFile);

HANAPI int __stdcall HNSnaptoJpg(int nChann,
								 char* szJpgFile,
								 long lImgQuality /*1~100*/);

//The buffer format is RGB24-format
HANAPI int __stdcall HNDrawBufftoImage(  int nChann,
										 UCHAR* pucBuffer,
										 long lBuffSize,
										 long lImgWidth,
										 long lImgHeight,
										 HWND hDrawWnd);

HANAPI int __stdcall HNDrawFiletoImage(	 int nChann,
										 char* pszImgFilePath,
										 HWND hDrawWnd);

//Only support YUY2 format and convert to RGB24 format
//Thes Min size of the RGBBuff is (lImgWidth x lImgHeight x 3)/* (r,g,b)*/
HANAPI int __stdcall HNConvertYUVtoRGB(int nChann,void* pYUVBuff,void* pRGBBuff,long lImgWidth, long lImgHeight,BOOL bInverted = TRUE);

HANAPI int __stdcall HNCloseImage( int nChann,HWND hDrawWnd);

//////////////////////////////////////////////////////////////////////////
HANAPI int __stdcall HNStartStreamDirectReadCallback( int nChann);

HANAPI int __stdcall HNStopStreamDirectReadCallback( int nChann);

HANAPI int __stdcall HNRegisterStreamDirectReadCallback( STREAM_DIRECT_READ_CALLBACK StreamDirectReadCallback,
													     void *Context);

HANAPI int __stdcall HNRegisterIOAlarmReadCallback( IOALARM_READ_CALLBACK IOAlarmReadCallback,
													void *Context);

HANAPI int __stdcall HNEnableIOAlarmReadCallback( int nChann,BOOL bEnable);
//////////////////////////////////////////////////////////////////////////
//
HANAPI int __stdcall HNSetCaptureFile( int nChann,
									  char* pszFile);

HANAPI int __stdcall HNStartStreamCapture(int nChann,TASK_t enTask);

HANAPI int __stdcall HNStopStreamCapture( int nChann);

HANAPI int __stdcall HNSetOsdDisplayMode(int nChann,
										 int Brightness, 
										 BOOL Translucent,
										 int x,
										 int y,
										 int nFontSize,
										 char* strText,
										 COLORREF clrText,
										 OsdFormat_t enOsdFormat);

HANAPI int __stdcall HNSetOsd(int nChann,
							  OsdFormat_t enOsdFormat,
							  BOOL Enable);

HANAPI int __stdcall HNReadEpprom(int nChann,BYTE* pData,int nAddr,int nSize);

HANAPI int __stdcall HNWriteEpprom(int nChann,BYTE* pData,int nAddr,int nSize);

HANAPI int __stdcall HNCopyImagetoClipboard(int nChann);

HANAPI int __stdcall HNGetSignalPresent(int nChann,int* pnSignalLock);

//lDeinterlaceType = 0xFF :stop deinterlace
HANAPI int __stdcall HNSetDeinterlaceType(int nChann,long lDeinterlaceType = 0);

HANAPI int __stdcall HNSetEncodIBP(int nChann, int KeyFrameIntervals, int BFrames, int PFrames);

HANAPI int __stdcall HNSetEncodQuant(int nChann, int nQuality);

HANAPI int __stdcall HNSetEncodBitRateControl(int nChann, BitrateControlType_t enCbr,ULONG ulPeekBps,ULONG ulBitRate);

#endif