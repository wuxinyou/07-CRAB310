/*==========================================================================*/
/*     (Copyright (C) 2011 ZhongAn Vision					.               */
/*     All rights reserved.                                                 */
/*																			*/
/* Module name  : HnLiveType.h  %version: 1 %								*/
/*																			*/
/* Last Update  : %date_modified: tony yu  %					*/
/*																			*/
/* Description: HnLiveSdk global type definitions.							*/
/*																			*/
/*==========================================================================*/

#ifndef HNLIVETYPE_H
#define HNLIVETYPE_H

typedef enum
{
	RET_NOERROR	= 0,		/* no error */
	RET_EXCEPTION,			/* sdk exception error */
	RET_ERR_INIT,			/* do not initialize or initialize failed */
	RET_INVALID_DEV,		/* do not find valid media device */
	RET_INVALID_CHANNEL,	/* invalid channel */
	RET_BAD_POINTER,		/* invalid or Null pointer param */
	RET_NO_MATCH,			/* do not match the compatiple object  */
	RET_DX_FAILED,			/* fail from direct show */
	RET_INVALID_HANDLE,		/* find null handle */
	RET_INVALID_PARAM,		/* invalid function param */
	RET_GDI_ERROR,			/* GDI error */
	RET_IO_ERROR,			/* common io read or write error */
	RET_FAILED,				/* common error */
	RET_VIDFMT_ERROR,		/* Video format selected do not support */
	RET_UNKNOWNERR,
}RETERRNO;

typedef enum 
{
    VIDEOPROCAMP_BRIGHTNESS,            // 
    VIDEOPROCAMP_CONTRAST,              //
    VIDEOPROCAMP_HUE,                   // 
    VIDEOPROCAMP_SATURATION,            // 
    VIDEOPROCAMP_SHARPNESS,             // 
    VIDEOPROCAMP_GAMMA,                 // 
    VIDEOPROCAMP_COLORENABLE,           // 
    VIDEOPROCAMP_WHITEBALANCE,          //
    VIDEOPROCAMP_BACKLIGHT_COMPENSATION,// 
    VIDEOPROCAMP_GAIN,                  // 
} VideoProCamp_t;


typedef enum
{					
    UYVY    = 0,                //@enum BO_1234 - YUV422        
    YUY2    = 1,                //@enum BO_2143 - YUV422 
	YV12    = 2,
    RGB24   = 3,                //@enum BO_1234 - RGB24
}VideoOutputFormat_t,*pVideoOutputFormat_t;

typedef enum
{
    COMPOSITE_1 = 0,            //@enum input is CVBS channel 1
    COMPOSITE_2,                //@enum input is CVBS channel 2
    S_VIDEO_1,                  //@enum input is S-Video channel 1
	S_VIDEO_2,
}VideoSource_t,*pVideoSource_t;

typedef enum
{           
    PAL         = 0,         //@enum normal PAL standard
    NTSC        = 1,         //@enum normal NTSC standard
	SECAM		= 2,		 //@enum normal SECAM standard
}VideoStandard_t,*pVideoStandard_t;


typedef enum
{  
	hnOddField        = 0x01,
	hnEvenField       = 0x02,
	hnInterlaced      = 0x03,
} StreamFlagsVideo_t;

typedef enum
{
	IMAGE_BMP,
	IMAGE_JPG,
}Image_t;


typedef enum
{
	OSD_TIME = 0,
	OSD_TEXT = 1,
	OSD_BMP  = 2,
}OsdFormat_t;

typedef enum
{
	TASK_PREVIEW = 0,	/* Only video stream preview */
	TASK_RECORD,		/* Only video stream capture */
	TASK_BOTH,			/* video stream preview + capture */
	TASK_NO,
}TASK_t;

typedef enum
{
	BITRATETYPE_CBR = 0,
	BITRATETYPE_VBR = 1,
}BitrateControlType_t;

//message
#define		HN_EVENT_NOTIFY	0x07E8

//message code
#define		HN_DEVICE_LOST	0x0001

//
typedef void (CALLBACK *STREAM_DIRECT_READ_CALLBACK)(ULONG channelNumber,void* pBuff,long lBuffSize,long lWidth,long lHeight,VideoOutputFormat_t enVidOutFmt,void* context);
typedef void (CALLBACK *IOALARM_READ_CALLBACK)(ULONG channelNumber,long lAlarmAddr,long lAlarmData,void* context);

#endif
