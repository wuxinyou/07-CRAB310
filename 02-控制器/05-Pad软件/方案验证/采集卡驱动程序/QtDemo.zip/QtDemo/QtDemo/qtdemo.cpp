#include "qtdemo.h"
#include <QMessageBox>
#include <QRect>
#include <qstring.h>

#pragma comment(lib,"DXMediaCap.lib")
#pragma comment(lib,"HnLiveSdk.lib")

    #ifdef UNICODE

    #define QStringToTCHAR(x)     (wchar_t*) x.utf16()

    #define PQStringToTCHAR(x)    (wchar_t*) x->utf16()

    #define TCHARToQString(x)     QString::fromUtf16((x))

    #define TCHARToQStringN(x,y)  QString::fromUtf16((x),(y))

    #else

    #define QStringToTCHAR(x)     x.local8Bit().constData()

    #define PQStringToTCHAR(x)    x->local8Bit().constData()

    #define TCHARToQString(x)     QString::fromLocal8Bit((x))

    #define TCHARToQStringN(x,y)  QString::fromLocal8Bit((x),(y))

    #endif
QtDemo::QtDemo(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
	int numDevice=0;
	DXInitialize();
	numDevice = DXGetDeviceCount();
	if (numDevice<1)
	{
		QMessageBox::about(this, "Notice", "No device");
	}
	else
	{

		//���豸
		
		deviceChancel = DXOpenDevice(0);  //���豸���������豸���
			RECT *prec = new  RECT();
		prec->left = 0;
			prec->top  = 0;
			prec->right = 720;
			prec->bottom = 576;	
	
		//�����豸
		int isConnect = -1;
		DXSetVideoPara(deviceChancel, 32, 2, 720, 576, 25);  //������Ƶ����
		isConnect=DXDeviceRun(deviceChancel);
	
			myWidget = new QLabel(this);
			myWidget->setGeometry(10, 10, 640, 480);
			myWidget->setFrameShape(QFrame::Box);

			HWND hand =HWND(myWidget->winId());
			//qDebug() << "hand "<<hand;
DXStartPreview(deviceChancel,hand,prec,0);
		
	
				QString strFilePath="d://1.jpg";

				char*  picPathName;

				QByteArray ba = strFilePath.toLatin1();    

				picPathName=ba.data();

				
	DXSnapToJPGFile(deviceChancel, picPathName, 100);

		
	}
		
}

QtDemo::~QtDemo()
{


}
