#ifndef QTDEMO_H
#define QTDEMO_H

#include <QtWidgets/QMainWindow>
#include "ui_qtdemo.h"
#include <windows.h>
#include "DXMediaCap.h"
#include "HnLiveMedia.h"
#include <QLabel>
#include <QString>



class QtDemo : public QMainWindow
{
	Q_OBJECT

public:
	QtDemo(QWidget *parent = 0);
	~QtDemo();
	HANDLE deviceChancel;

private:
	Ui::QtDemoClass ui;
	QLabel *myWidget;
};

#endif // QTDEMO_H
